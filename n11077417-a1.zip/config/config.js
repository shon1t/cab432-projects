module.exports = {
    PORT: 3000,
    TOKEN_SECRET: "amazing-spiderman",
}